﻿app.controller("SuperAdminController", function ($scope, $http) {
    $scope.model = {};
    $scope.Detmodel = {};
    $scope.model.txtSearch = "";
    $scope.model.IsEdit = false;
    $scope.GroupId = "";
    $scope.HideLoaderImg = function () {
        $('#LoadingImg').hide();
    }

    $scope.ShowLoaderImg = function () {
        $('#LoadingImg').show();
    }

    $scope.GroupSearch = function () {
        $("#mainGrid").data("kendoGrid").dataSource.read();
    }

    $scope.mainGridOptions = {
        dataSource: {
            type: "json",
            transport: {
                read: {
                    url: baseUrl + "Group/GetUsers",
                    dataType: "json",
                },
                parameterMap: function (options, operation) {
                    debugger;
                    var opt = {};
                    opt = options;
                    opt.Search = $scope.model.txtSearch;
                    return opt;
                },
            },
            schema:
            {
                model:
                {
                    id: "Id",
                    fields: {

                    }
                }
            },

            serverPaging: true,
            schema: {
                data: function (response) {
                    if (response.Result) {
                        return JSON.parse(response.Result);
                    }
                    return [];
                },
                total: 'Total',

            }
        },

        sortable: {
            mode: "single",
            allowUnsort: true
        },


        pageable: { pageSize: GridPageSize, refresh: true },

        resizeable: true,
        scrollable: false,
      
        //specify columns that you want to display   
        columns: [
            {
                field: "Name",
                title: "Employee",
                width: "80px",
                filterable: false,

            },
            {
                field: "code",
                title: "Code",
                width: "80px",
                filterable: false,

            },
            {
                field: "SuperAdminString",
                title: "Is SuperAdmin",
                width: "80px",
                filterable: false,
            },
           
            {
              

                template: "#  if (SuperAdminString == 'Yes' ) { # <a href='javascript:void(0);' ng-click='changeStatus(this)'  data-toggle='tooltip' title='Remove Super Admin' <i class='las la-times-circle text-danger'></i> </a> #} \
                  else if (SuperAdminString == 'No' ) { # <a href='javascript:void(0);' ng-click='changeStatus(this)'  data-toggle='tooltip' title='Make Super Admin' <i class='las la-info-circle'></i> </a> #} \#",                  
                width: "40px",
                title: "Action",
                headerAttributes: { style: "text-align:center;" },
                attributes: { style: "text-align:center;" },

            },

        ]
    };
   

    $scope.changeStatus = function (obj) {
        debugger;
        var currentAccess = "";
        if (obj.dataItem.SuperAdminString=="Yes")
            currentAccess = "remove";
        else
            currentAccess = "give";
        var warnText = "Are you sure you want to " + currentAccess+ " Super Admin access?";
        $.when(showConfirmationWindow(warnText)).then(function (confirmed) {
            if (confirmed) {
                $scope.ShowLoaderImg();
                $http({
                    method: 'GET',
                    url: baseUrl + 'Group/ChangeSuperAdmin?Id=' + obj.dataItem.Id + "&IsAdmin=" + obj.dataItem.SuperAdminString,

                }).then(function (response) {
                    debugger;
                    $scope.HideLoaderImg()
                    SetMessage('Update');                   
                    $("#mainGrid").data("kendoGrid").dataSource.read();


                }, function errorCallback(response) {
                    $scope.HideLoaderImg();
                    SetMessage('Error');

                });
            }
        });


    }

});